%% Question B � D�terminer le moment de F
% Sauvegarder sans d�lai sous BCIPV4321, o� CIPV4321 est votre CIP

%% Initialisation
clear; clc

%% �tape 1 � D�marche vectorielle

%% �tape 2 � Expression scalaire du moment