%% Diviseur.m
% Objectif : R�tablir l'indentation des
% instructions.

%% Comment r�tablir l'indetation
% Pour rendre le texte plus convivial,
% il faut d�caler les instructions de d�cision.
% Examiner les items du menu de l'�diteur :
%
% * Edit : Select all, touche {Ctrl + A}
% * Text : Smart indent {Ctrl + I}
%
% En appuyant sur les touches
%    {Ctrl + A} et {Ctrl + I},
% les �nonc�s sont � nouveau d�cal�s correctement.

%% Contexte
% Le script g�n�re un nombre entier compris entre
% 1 et 30. Par la suite, il d�termine si le nombre
% est divisible par 3 et 5.
%
% Le script utilise la fonction rem et floor.
%
% * rand : g�n�re un nombre al�atoire compris
% entre 0 et 1.
% * floor : conserve la partie enti�re d'un
% nombre.
% * rem : calcule le reste apr�s une division.
%
% Ces fonctions ne sont pas mati�re � examen.

clear; clc
N = floor(1+29.99*rand);
fprintf('Nombre g�n�r� : %.0f\n',N);
divisiblePar5 = rem(N,5)==0;
divisiblePar3 = rem(N,3)==0;
%%
% Choix de d�cisions binaires imbriqu�es
% propices � l'objectif de l'exercice.

if(divisiblePar3)
if(divisiblePar5)
fprintf(['%.0f est divisible ',...
'par 3 et 5.\n'],N);
else
fprintf('%.0f est divisible par 3.\n',N);
end
else
if(divisiblePar5)
fprintf('%.0f est divisible par 5.\n',N)
else
fprintf('%.0f n''est pas divisible',N);
fprintf(' par 3 et 5.\n');
end
end