%% Comment afficher un texte contigu. 
% Instruction : faire ex�cuter le script en mode
% _Publish to html_ et observer le r�sultat.

%% R�initialisation et info
% Pour �crire un texte contigu en html, il suffit
% de concevoir une cellule et d'�crire en
% commentaire imm�diatement dans les lignes qui
% suivent.
% 
% Chaque commentaire d�bute par � % � et
% le texte doit commencer � la colonne 3.
clear; clc; 
close all % close all est utile pour effacer toutes les figures existantes

%% Exemple
% Observer qu'il y a quatre lignes dans le script
% apr�s � %% � et que le texte est contigu.
% Une cellule commence par � %% � et le texte
% d�bute � la colonne 3.

theta = asind(0.5) % pour illustrer

%%
% Dans cette cellule, il n'y a pas de texte
% sur la m�me ligne que le d�but de la cellule
% (%%).
%
% La premi�re cellule g�n�re un hyperlien dans la
% table des mati�res, alors que ce n'est pas le
% cas pour cette cellule-ci.

%% Contre-exemple 1
%Il n'y a pas un (1) espace � la colonne 2.
% Ce texte n'est pas contigu.

%% Contre-exemple 2
theta2 = asind(0.3) % pour illustrer
% Le texte ne suit pas imm�diatement le d�but de
% la cellule. Il n'est donc pas contigu.


%% Ex�cution des instructions
% Les instructions sont ex�cut�es cellule par
% cellule, ce qui am�liore la compr�hension d'un
% script.
%
% Voil� pour l'essentiel !